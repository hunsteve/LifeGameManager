function verify(neptun)
result=0;
try
	
	load 'food_simple_pretest.mat';	
	n=300;	
	err = zeros(n,1);
	cd(neptun);
	diary('matlab_output.txt');	
	
	for j=1:n
		ay = player_i_eat(xy(j,:));		
		assert(isscalar(ay),'Error: function output is not scalar!');
		assert((ay == 1) || (ay == -1),['Error: function output is not +1 or -1, but ',num2str(ay),', which is not a valid class!']);
		err(j) = ((d(j,:)' == 1) ~= (ay == 1));
    end

  	err_ratio=mean(err);
    result=err_ratio<0.18;
	disp('Az elert hibas osztalyozasi arany:');
	err_ratio
    
catch err
	disp('ERROR:');
	disp(['   ',err.message]);
    disp('STACK TRACE:');
    for(i=1:length(err.stack)-1) 
        disp(['   line: ', num2str(err.stack(i).line),'   method: ', err.stack(i).name ]); 
    end
end
resultfile=fopen('result.txt','w');
fprintf(resultfile,'%d',result);
fclose(resultfile);
diary off;
exit;