function verify(neptun)
result=0;
try
	
	load 'fight_pretest.mat';
	index = randperm(size(x,1));
	n=300;
	xx=x(index(1:n),:);
	yy=y(index(1:n),:);
	err = zeros(n,1);	
	cd(neptun);
	diary('matlab_output.txt');	
	
	for j=1:n
		ay = player_i_fight(xx(j,:));
		err(j) = yy(j,:) - ay;
    end

  	MSE=mean(err.^2);
   	result=MSE<0.05;
	disp('Az elert atlagos negyzetes hiba:');
	MSE
catch err
    disp('ERROR:');
	disp(['   ',err.message]);
    disp('STACK TRACE:');
    for(i=1:length(err.stack)-1) 
        disp(['   line: ', num2str(err.stack(i).line),'   method: ', err.stack(i).name ]); 
    end
end
resultfile=fopen('result.txt','w');
fprintf(resultfile,'%d',result);
fclose(resultfile);
diary off;
exit;