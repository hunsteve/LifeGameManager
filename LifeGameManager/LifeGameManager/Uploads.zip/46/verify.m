function verify(neptun)
result=0;
try
	tempname = strcat([neptun,'_']);
	movefile(neptun,tempname);
	playersdir=strcat([neptun,'\players\']);
	mkdir(playersdir);
	movefile(tempname,playersdir);
	movefile(strcat([playersdir,tempname]), strcat([playersdir,neptun]));
	unzip('full_pretest.zip',neptun);	
	cd(neptun);
	diary('matlab_output.txt');		
	
	[popsize, randpopsize] = start(neptun);	
	result=(popsize >= 2*randpopsize); 
	disp('Az elert populaciomeret:');
	popsize
	disp('A random agens populaciomerete:');
	randpopsize
catch err
	disp('ERROR:');
	disp(['   ',err.message]);
	disp('STACK TRACE:');
	for(i=1:length(err.stack)-1) 
		disp(['   line: ', num2str(err.stack(i).line),'   method: ', err.stack(i).name ]); 
	end
end
resultfile=fopen('result.txt','w');
fprintf(resultfile,'%d',result);
fclose(resultfile);
diary off;
exit;