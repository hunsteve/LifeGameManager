function verify(neptun)
result=0;
try
	
	load 'food_pretest.mat';

    food_arr = [t,x];
    food_arr_max = max(x);
    food_arr_min = min(x);

    x_start=511;
    y_start=534;

    prediction_offset = 5;

    maxdist = 5;

    n = 100;
    k = 3;

    field_x=100; %Field size in x
    field_y=100; %Field size in y
    score = 0;

	cd(neptun);
	diary('matlab_output.txt');	
	
    for j=1:k
        field = zeros(field_x,field_y,2); %Initial all-0 field
        for i=1:10     
            coords = floor(rand(1,2).*[field_x, field_y]+ones(1,2));
            field(coords(1,1),coords(1,2),1) = player_color;
            field(coords(1,1),coords(1,2),2) = 100; %kezdo hp
        end

        for i=1:n
            food_offset_x = i;
            food_offset_y = i;
            food_arr_x = food_arr(1:x_start+food_offset_x,:);
            food_arr_y = food_arr(1:y_start+food_offset_y,:);

            [from_x,from_y,to_x,to_y] = player_i_step(field,player_color,food_arr_x,food_arr_y,food_arr_min,food_arr_max);

            food_x = ceil((((food_arr(x_start+food_offset_x+prediction_offset,2)-food_arr_min)/(food_arr_max-food_arr_min))*field_x)+0.01);
            food_y = ceil((((food_arr(y_start+food_offset_y+prediction_offset,2)-food_arr_min)/(food_arr_max-food_arr_min))*field_y)+0.01);

            if((from_x <= field_x && from_x >= 1 && from_y <= field_y && from_y >= 1) && (to_x <= field_x && to_x >= 1 && to_y <= field_y && to_y >= 1))        
                if (~(field(from_x,from_y,1) == player_color))
                    error('Hibas lepes: nem sajat jatekossal akart lepni!');
                elseif (from_x ==to_x && from_y == to_y)
                    error('Hibas lepes: forras es cel pozicio nem lehet ugyanaz!');            
                elseif (field(to_x,to_y,1) ~= 0)
                    error('Hibas lepes: a celmezo nem ures!');            
                end            
            else
                error('Hibas lepes: kilepett a palyarol, vagy palyan kivulrol akart lepni!');
            end; 

            field(to_x, to_y,:)=field(from_x, from_y,:);
            field(from_x, from_y,:) = [0,0];



            %score = score + sum(sum(field(max(50-maxdist,0):min(50+maxdist,end),max(50-maxdist,0):min(50+maxdist,end),1)==player_color));   
            score = score + sum( sum(field(max(food_x-maxdist,1):min(food_x+maxdist,100),max(food_y-maxdist,1):min(food_y+maxdist,100),1)==player_color));
        end
    end

    score = score / n / k;
    result=score>0.4;
    disp('Az elert atlagos eredmeny:');
	score      
catch err
	disp('ERROR:');
	disp(['   ',err.message]);
    disp('STACK TRACE:');
    for(i=1:length(err.stack)-1) 
        disp(['   line: ', num2str(err.stack(i).line),'   method: ', err.stack(i).name ]); 
    end
end
resultfile=fopen('result.txt','w');
fprintf(resultfile,'%d',result);
fclose(resultfile);
diary off;
exit;


